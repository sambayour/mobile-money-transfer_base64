<?php
    include "validate_customer.php";
    include "header.php";
    include "customer_navbar.php";
    include "customer_sidebar.php";
    include "session_timeout.php";
$txt = '';
$Ee = '';
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="customer_add_style.css">
</head>

<body>
    <?php
  if(isset($_POST['submit'])){

$pin = "<hgmn3>";
$pine = "</hg,3>";

$afo = $_POST['textmsg'];
 $Ee = base64_encode($pin.$afo.$pine);
echo "<br>";
 $newstr = filter_var($Ee, FILTER_SANITIZE_STRING);
echo "<br>";
// echo base64_decode($Ee);
// echo "<textarea> base64_decode($newstr) </textarea>"
  $txt = base64_decode($newstr);


  }
  if(isset($_POST['esubmit']) & isset($_POST['textmsg'])) {

    $pin = "<hgmn3>";
$pine = "</hg,3>";

$afo = $_POST['textmsg'];
 $Ee = base64_decode($afo);
echo "<br>";
 $newstr = filter_var($Ee, FILTER_SANITIZE_STRING);
echo "<br>";
// echo base64_decode($Ee);
// echo "<textarea> base64_decode($newstr) </textarea>"
 // echo $txt = base64_decode($newstr);


  }
  
    ?>

<?php 
 echo date('Y-m-d H:i:s');  ?>
    <form  action="" method="post">
        <div class="flex-container-form_header">
            <h1 id="form_header">SMS Reader</h1>
        </div>
             <div class="flex-container">
                <center style="padding: 22px;">
         <h3>
            <i>
                <?php echo $txt ?>                    
                <?php echo $Ee ?> 
                </i>
            </h3>
                </center>
             </div>

     <div class="flex-container">
            <div  class=container>
                <label>SMS :</b></label><br>
            <textarea name="textmsg" required=""> </textarea>  

     </div>
        </div>

        <div class="flex-container">
            <div class="container">
                <button name="submit" type="submit">Decode</button>
            </div>
            <div class="container">
                <button name="esubmit" type="submit">Encode</button>
            </div>

            <div class="container">
                <button type="reset" class="reset">Reset</button>
            </div>
        </div>

    </form>

</body>
</html>

