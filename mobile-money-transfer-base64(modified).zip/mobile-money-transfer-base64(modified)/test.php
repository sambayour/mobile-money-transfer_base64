<?php
   $pin = "<h1>";
$pine = "</h1>";

$afo = "afolabi";
echo $Ee = base64_encode($pin.$afo.$pine);
echo "<br>";
echo $newstr = filter_var($Ee, FILTER_SANITIZE_STRING);

// echo base64_decode($Ee);
// echo "<textarea> base64_decode($newstr) </textarea>";
echo base64_decode($newstr);

?> 


<!DOCTYPE html>
<html>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="knockout-3.5.0rc2.js"></script>
<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
<body>
<!-- 
<?php
// Variable to check
$str = "<h1>Hello World!</h1>";

// Remove HTML tags from string
$newstr = filter_var($str, FILTER_SANITIZE_STRING);
echo $newstr;
?>
 --><input type="button" checked data-toggle="toggle" value="Toggle" data-bind="click: toggleView"/>


<div data-bind="visible: showGrid()">Grid</div>
<div data-bind="visible: !showGrid()">List</div>

 <input type="radio" value="Toggle" data-bind="click: toggleView"/>

</body>
<script type="text/javascript">
	var ViewModel = function() {
    var self = this;
    
    self.showGrid = ko.observable(true);
    self.toggleView = function() {
        self.showGrid(!self.showGrid());
    }
}

var vm = new ViewModel();
ko.applyBindings(vm);
</script>
</html>