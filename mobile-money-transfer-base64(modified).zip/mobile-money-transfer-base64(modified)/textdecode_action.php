<?php

 include "validate_customer.php";
 include "header.php";
 include "customer_navbar.php";
 include "customer_sidebar.php";
 include "session_timeout.php";

?>