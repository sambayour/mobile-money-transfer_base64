<?php
    include "validate_customer.php";
    include "header.php";
    include "customer_navbar.php";
    include "customer_sidebar.php";
    include "session_timeout.php";
    
    $so='23421';

    $id = $_SESSION['loggedIn_cust_id'];

    $sql0 = "SELECT * FROM customer WHERE cust_id=".$id;
    $result0 = $conn->query($sql0);
    $row0 = $result0->fetch_assoc();

    $sql1 = "SELECT * FROM passbook".$id." WHERE trans_id=(
                    SELECT MAX(trans_id) FROM passbook".$id.")";
    $result1 = $conn->query($sql1);
    $row1 = $result1->fetch_assoc();

    if ($row1["debit"] == 0) {
        $transaction = $row1["credit"];
        $type = "credit";
    }
    else {
        $transaction = $row1["debit"];
        $type = "debit";
    }

    $time = strtotime($row1["trans_date"]);
    $sanitized_time = date("d/m/Y, g:i A", $time);

    $sql2 = "SELECT COUNT(*) FROM beneficiary".$id;
    $result2 = $conn->query($sql2);
    $row2 = $result2->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin_home_style.css">
<script src="knockout-3.5.0rc2.js"></script>
</head>

<body>
    <div class="flex-container">
      <div data-bind="visible: showGrid()">
        <div class="flex-item">
            <h1 id="customer">
                Welcome, <?php echo $row0["first_name"] ?>&nbsp<?php echo $row0["last_name"] ?>&nbsp!
                <br>AC/No: <?php echo $rr = substr(base64_encode($row0["account_no"]), 0, 7) ;?>
            </h1>
            <p id="customer">
                &#9656 Balance (₦): <?php echo $rr = substr(base64_encode($row1["balance"]), 0, 6) ; ?> 
                <br>&#9656 You have <?php echo $rr = substr(base64_encode($row2["COUNT(*)"]), 0, 6) ;?> beneficiaries.
                <br>&#9656 Your last transaction (<?php echo $rr = substr(base64_encode($type), 0, 6) ;?>) of&nbsp₦&nbsp<?php
                echo $rr = substr(base64_encode(number_format($transaction)), 0, 6) ; ?>
                <br>
                on 
                <?php echo  $rr = substr(base64_encode($sanitized_time), 0, 6); ?>, 
                was: 
                "<?php echo $rr = substr(base64_encode($row1["remarks"]), 0, 6); ?>".
            </p>
        </div>
       </div>

 
<div data-bind="visible: !showGrid()">

   <div class="flex-item">
            <h1 id="customer">
                Welcome, <?php echo $row0["first_name"] ?>&nbsp<?php echo $row0["last_name"] ?>&nbsp!
                <br>AC/No: <?php echo $row0["account_no"]; ?>
            </h1>
            <p id="customer">
                &#9656 Balance (₦): <?php echo number_format($row1["balance"]) ; ?> 
                <br>&#9656 You have <?php echo $row2["COUNT(*)"]; ?> beneficiaries.
                <br>&#9656 Your last transaction (<?php echo $type; ?>) of&nbsp₦&nbsp<?php
                echo number_format($transaction); ?><br>
                on <?php echo $sanitized_time; ?>, was: "<?php echo $row1["remarks"]; ?>".                
            </p>
        </div>
</div>
        <center>
     <input type="button" checked data-toggle="toggle" value="Switch" data-bind="click: toggleView"/>
</center>
    </div>

</body>
<script type="text/javascript">
    var ViewModel = function() {
    var self = this;
    
    self.showGrid = ko.observable(true);
    self.toggleView = function() {
        self.showGrid(!self.showGrid());
    }
}

var vm = new ViewModel();
ko.applyBindings(vm);
</script>
</html>

<?php include "easter_egg.php"; ?>
